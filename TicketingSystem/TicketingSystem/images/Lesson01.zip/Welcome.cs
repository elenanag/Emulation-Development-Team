// Namespace Declaration
using System;

// Program start class
class WelcomeCSS 
{
	// Main begins program execution.
	static void Main() 
	{
		// Write to console
		Console.WriteLine("Welcome to the C# Station Tutorial!");�

		// Make window wait for input
		Console.ReadLine();
	}
}
